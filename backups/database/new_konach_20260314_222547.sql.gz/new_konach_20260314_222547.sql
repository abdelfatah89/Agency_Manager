-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: new_konach
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_accounts_name` (`account_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agencies`
--

DROP TABLE IF EXISTS `agencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `agency_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `agency_type` enum('CashPlus','TPE','bank','other') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `total_cashplus_transaction` decimal(14,2) NOT NULL DEFAULT '0.00',
  `alimentation` decimal(14,2) NOT NULL DEFAULT '0.00',
  `balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_agencies_name` (`agency_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agencies`
--

LOCK TABLES `agencies` WRITE;
/*!40000 ALTER TABLE `agencies` DISABLE KEYS */;
INSERT INTO `agencies` VALUES (1,'tam','CashPlus',84793.88,3850.00,-80943.88,1,'2026-03-14 10:22:15','2026-03-14 22:15:12');
/*!40000 ALTER TABLE `agencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `cin` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ice` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total_paid` decimal(14,2) NOT NULL DEFAULT '0.00',
  `rest` decimal(14,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_clients_cin` (`cin`),
  UNIQUE KEY `uq_clients_ice` (`ice`),
  KEY `idx_clients_name` (`full_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'abdo','dfdffd',NULL,'k','df',84793.88,3850.00,80943.88,'2026-03-14 10:22:27','2026-03-14 22:02:17');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmi_transactions`
--

DROP TABLE IF EXISTS `cmi_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cmi_transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_date` date NOT NULL,
  `agency_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `paid_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cost` decimal(14,2) NOT NULL DEFAULT '0.00',
  `commission` decimal(14,2) NOT NULL DEFAULT '0.00',
  `alimentation` decimal(14,2) NOT NULL DEFAULT '0.00',
  `designation` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cmi_date` (`transaction_date`),
  KEY `idx_cmi_agency_name` (`agency_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmi_transactions`
--

LOCK TABLES `cmi_transactions` WRITE;
/*!40000 ALTER TABLE `cmi_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `cmi_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_balance`
--

DROP TABLE IF EXISTS `daily_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_balance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `daily_id` int(10) unsigned NOT NULL,
  `opening_balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total_output` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total_input` decimal(14,2) NOT NULL DEFAULT '0.00',
  `closing_balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_daily_balance_daily_id` (`daily_id`),
  CONSTRAINT `fk_daily_balance_daily` FOREIGN KEY (`daily_id`) REFERENCES `daily_sessions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_balance`
--

LOCK TABLES `daily_balance` WRITE;
/*!40000 ALTER TABLE `daily_balance` DISABLE KEYS */;
INSERT INTO `daily_balance` VALUES (3,1,0.00,0.00,3850.00,3850.00,'2026-03-14 10:23:39','2026-03-14 22:05:55'),(4,7,450000.00,0.00,0.00,450000.00,'2026-03-14 16:34:40','2026-03-14 16:39:24'),(5,8,202563.00,1000.00,83793.88,243991.35,'2026-03-14 16:39:48','2026-03-14 22:06:10'),(6,9,77665.00,0.00,0.00,77665.00,'2026-03-14 17:05:12','2026-03-14 17:05:12'),(7,10,0.00,0.00,0.00,0.00,'2026-03-14 17:27:59','2026-03-14 17:27:59'),(8,11,0.00,0.00,0.00,0.00,'2026-03-14 22:05:56','2026-03-14 22:05:56'),(9,12,0.00,0.00,0.00,0.00,'2026-03-14 22:05:56','2026-03-14 22:05:56');
/*!40000 ALTER TABLE `daily_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_cash`
--

DROP TABLE IF EXISTS `daily_cash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_cash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `daily_id` int(10) unsigned NOT NULL,
  `cash_10000` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cash_200` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cash_100` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cash_50` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cash_20` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cash_10` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cash_5` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cash_1` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total_cash` decimal(14,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_daily_cash_daily_id` (`daily_id`),
  CONSTRAINT `fk_daily_cash_daily` FOREIGN KEY (`daily_id`) REFERENCES `daily_sessions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_cash`
--

LOCK TABLES `daily_cash` WRITE;
/*!40000 ALTER TABLE `daily_cash` DISABLE KEYS */;
INSERT INTO `daily_cash` VALUES (3,1,45.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,450000.00,'2026-03-14 10:23:39','2026-03-14 15:50:34'),(4,7,0.00,0.00,0.00,0.00,0.00,0.00,0.00,202563.00,202563.00,'2026-03-14 16:34:40','2026-03-14 16:39:44'),(5,8,6.00,0.00,46.00,173.00,202.00,22.00,31.00,0.00,77665.00,'2026-03-14 16:39:48','2026-03-14 16:44:04'),(6,9,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'2026-03-14 17:05:12','2026-03-14 17:05:12'),(7,10,1.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,10000.00,'2026-03-14 17:27:59','2026-03-14 17:28:10'),(8,11,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'2026-03-14 22:05:56','2026-03-14 22:05:56'),(9,12,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'2026-03-14 22:05:56','2026-03-14 22:05:56');
/*!40000 ALTER TABLE `daily_cash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_operation_summary`
--

DROP TABLE IF EXISTS `daily_operation_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_operation_summary` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `daily_id` int(10) unsigned NOT NULL,
  `input_transactions` decimal(14,2) NOT NULL DEFAULT '0.00',
  `input_transaction_outin` decimal(14,2) NOT NULL DEFAULT '0.00',
  `output_transactions` decimal(14,2) NOT NULL DEFAULT '0.00',
  `output_transaction_outin` decimal(14,2) NOT NULL DEFAULT '0.00',
  `input_transactions_account` decimal(14,2) NOT NULL DEFAULT '0.00',
  `output_transactions_account` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total_bills` decimal(14,2) NOT NULL DEFAULT '0.00',
  `vignette` decimal(14,2) NOT NULL DEFAULT '0.00',
  `phone_recharge` decimal(14,2) NOT NULL DEFAULT '0.00',
  `retailer` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cp_merchant` decimal(14,2) NOT NULL DEFAULT '0.00',
  `rest_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total_result` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cmi_tamezmoute` decimal(14,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_daily_operation_summary_daily_id` (`daily_id`),
  CONSTRAINT `fk_daily_operation_summary_daily` FOREIGN KEY (`daily_id`) REFERENCES `daily_sessions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_operation_summary`
--

LOCK TABLES `daily_operation_summary` WRITE;
/*!40000 ALTER TABLE `daily_operation_summary` DISABLE KEYS */;
INSERT INTO `daily_operation_summary` VALUES (3,1,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'2026-03-14 10:23:39','2026-03-14 10:23:39'),(4,7,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,450000.00,0.00,0.00,'2026-03-14 16:34:41','2026-03-14 16:39:24'),(5,8,36914.35,0.00,28454.70,0.00,35166.00,15924.00,5310.00,0.00,40.00,7500.00,-39480.00,203634.65,1071.65,41116.20,'2026-03-14 16:39:48','2026-03-14 22:06:10'),(6,9,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,77665.00,0.00,0.00,'2026-03-14 17:05:12','2026-03-14 17:07:59'),(7,10,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'2026-03-14 17:27:59','2026-03-14 17:27:59'),(8,11,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'2026-03-14 22:05:56','2026-03-14 22:05:56'),(9,12,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'2026-03-14 22:05:56','2026-03-14 22:05:56');
/*!40000 ALTER TABLE `daily_operation_summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_sessions`
--

DROP TABLE IF EXISTS `daily_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `session_date` date NOT NULL,
  `status` enum('open','closed') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `notes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `opened_by` int(10) unsigned DEFAULT NULL,
  `closed_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_daily_sessions_date` (`session_date`),
  KEY `fk_daily_sessions_opened_by` (`opened_by`),
  KEY `fk_daily_sessions_closed_by` (`closed_by`),
  CONSTRAINT `fk_daily_sessions_closed_by` FOREIGN KEY (`closed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_daily_sessions_opened_by` FOREIGN KEY (`opened_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_sessions`
--

LOCK TABLES `daily_sessions` WRITE;
/*!40000 ALTER TABLE `daily_sessions` DISABLE KEYS */;
INSERT INTO `daily_sessions` VALUES (1,'2026-03-14','open',NULL,NULL,NULL,'2026-03-14 10:22:54','2026-03-14 10:28:34'),(7,'2026-03-15','open',NULL,NULL,NULL,'2026-03-14 16:34:40','2026-03-14 16:34:40'),(8,'2026-03-16','open',NULL,NULL,NULL,'2026-03-14 16:39:48','2026-03-14 16:39:48'),(9,'2026-03-17','open',NULL,NULL,NULL,'2026-03-14 17:05:12','2026-03-14 17:05:12'),(10,'2026-03-18','open',NULL,NULL,NULL,'2026-03-14 17:27:59','2026-03-14 17:27:59'),(11,'2026-03-13','open',NULL,NULL,NULL,'2026-03-14 22:05:56','2026-03-14 22:05:56'),(12,'2026-03-12','open',NULL,NULL,NULL,'2026-03-14 22:05:56','2026-03-14 22:05:56');
/*!40000 ALTER TABLE `daily_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `general_balance`
--

DROP TABLE IF EXISTS `general_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `general_balance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `daily_id` int(10) unsigned NOT NULL,
  `opening_balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `agencies_balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cashplus_balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `bank_balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cmi_tamezmoute` decimal(14,2) NOT NULL DEFAULT '0.00',
  `closing_balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `balance_variance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_general_balance_daily_id` (`daily_id`),
  CONSTRAINT `fk_general_balance_daily` FOREIGN KEY (`daily_id`) REFERENCES `daily_sessions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `general_balance`
--

LOCK TABLES `general_balance` WRITE;
/*!40000 ALTER TABLE `general_balance` DISABLE KEYS */;
INSERT INTO `general_balance` VALUES (5,1,-80943.88,-80943.88,0.00,0.00,0.00,365206.12,446150.00,'2026-03-14 10:27:01','2026-03-14 22:05:57'),(6,7,365206.12,-80943.88,0.00,0.00,0.00,121619.12,-243587.00,'2026-03-14 16:34:41','2026-03-14 22:06:13'),(7,8,121619.12,-80943.88,0.00,0.00,41116.20,-45778.88,-167398.00,'2026-03-14 16:39:48','2026-03-14 22:06:10'),(8,9,-45778.88,-80943.88,0.00,0.00,0.00,-80943.88,-35165.00,'2026-03-14 17:05:12','2026-03-14 22:05:57'),(9,10,-80943.88,-80943.88,0.00,0.00,0.00,-70943.88,10000.00,'2026-03-14 17:28:12','2026-03-14 22:03:29'),(10,11,-80943.88,-80943.88,0.00,0.00,0.00,-80943.88,0.00,'2026-03-14 22:05:56','2026-03-14 22:05:57'),(11,12,0.00,-80943.88,0.00,0.00,0.00,-80943.88,-80943.88,'2026-03-14 22:05:56','2026-03-14 22:15:12');
/*!40000 ALTER TABLE `general_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `daily_id` int(10) unsigned NOT NULL,
  `transaction_date` date NOT NULL,
  `client_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `paid_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `balance_due` decimal(14,2) NOT NULL DEFAULT '0.00',
  `today_in` tinyint(1) NOT NULL DEFAULT '0',
  `today_out` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_transactions_daily_id` (`daily_id`),
  KEY `idx_transactions_date` (`transaction_date`),
  KEY `idx_transactions_client_name` (`client_name`),
  KEY `idx_transactions_account_name` (`account_name`),
  CONSTRAINT `fk_transactions_daily` FOREIGN KEY (`daily_id`) REFERENCES `daily_sessions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (11,8,'2026-03-16','abdo','tam','dfgd',83793.88,0.00,83793.88,0,1,'2026-03-14 16:43:04'),(12,8,'2026-03-16','abdo','tam','fg',0.00,1000.00,-1000.00,1,0,'2026-03-14 16:43:19'),(13,1,'2026-03-14','abdo','tam','g',1000.00,0.00,1000.00,0,1,'2026-03-14 16:50:05'),(14,1,'2026-03-14','abdo','tam','ygh',0.00,2850.00,-2850.00,0,1,'2026-03-14 16:50:29');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','manager','user') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','pbkdf2_sha256$390000$2c49ccba49e2551ceb43522b31857b29$16hdFAG8S9lS4XDTEh7+1dztht6oeKYcu+kYzViV43Y=','admin','2026-03-14 18:07:24');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'new_konach'
--

--
-- Dumping routines for database 'new_konach'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-14 22:25:48
