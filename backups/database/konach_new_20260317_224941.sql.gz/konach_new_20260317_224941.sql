-- MySQL dump 10.13  Distrib 8.0.17, for Win64 (x86_64)
--
-- Host: localhost    Database: konach_new
-- ------------------------------------------------------
-- Server version	8.0.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_accounts_name` (`account_name`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` VALUES (1,'AGENCE TAMEZOUT',1,'2026-03-17 21:22:57'),(2,'بنك',1,'2026-03-17 21:22:57'),(3,'الصندوق',1,'2026-03-17 21:22:57'),(4,'CMI-TIN',1,'2026-03-17 21:22:57'),(5,'مصاريف',1,'2026-03-17 21:22:57'),(6,'TAFT-aissam',1,'2026-03-17 21:22:57'),(7,'AFRA',1,'2026-03-17 21:22:57'),(8,'زبناء',1,'2026-03-17 21:22:57'),(9,'الصرف',1,'2026-03-17 21:22:57'),(10,'المبيعات',1,'2026-03-17 21:22:57'),(11,'غير محدد',1,'2026-03-17 21:22:57'),(12,'ag-zineb',1,'2026-03-17 21:22:57'),(13,'السلف',1,'2026-03-17 21:22:57'),(14,'صحراوي',1,'2026-03-17 21:22:57'),(15,'المشتريات',1,'2026-03-17 21:22:57');
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agencies`
--

DROP TABLE IF EXISTS `agencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `agencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `agency_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `agency_type` enum('CashPlus','TPE','bank','other') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'other',
  `total_cashplus_transaction` decimal(14,2) NOT NULL DEFAULT '0.00',
  `alimentation` decimal(14,2) NOT NULL DEFAULT '0.00',
  `balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_agencies_name` (`agency_name`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agencies`
--

LOCK TABLES `agencies` WRITE;
/*!40000 ALTER TABLE `agencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `agencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cin` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ice` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total_paid` decimal(14,2) NOT NULL DEFAULT '0.00',
  `rest` decimal(14,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_clients_cin` (`cin`),
  UNIQUE KEY `uq_clients_ice` (`ice`),
  KEY `idx_clients_name` (`full_name`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (25,'abdo','pn8778',NULL,'0737373','hs',109118.66,32600.00,76518.66,'2026-03-17 21:34:35','2026-03-17 22:31:48');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cmi_transactions`
--

DROP TABLE IF EXISTS `cmi_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cmi_transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_date` date NOT NULL,
  `agency_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `paid_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cost` decimal(14,2) NOT NULL DEFAULT '0.00',
  `commission` decimal(14,2) NOT NULL DEFAULT '0.00',
  `alimentation` decimal(14,2) NOT NULL DEFAULT '0.00',
  `designation` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_cmi_date` (`transaction_date`),
  KEY `idx_cmi_agency_name` (`agency_name`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cmi_transactions`
--

LOCK TABLES `cmi_transactions` WRITE;
/*!40000 ALTER TABLE `cmi_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `cmi_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_balance`
--

DROP TABLE IF EXISTS `daily_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_balance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `daily_id` int(10) unsigned NOT NULL,
  `opening_balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total_output` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total_input` decimal(14,2) NOT NULL DEFAULT '0.00',
  `local_agency_balane` decimal(14,2) NOT NULL DEFAULT '0.00',
  `closing_balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_daily_balance_daily_id` (`daily_id`),
  CONSTRAINT `fk_daily_balance_daily` FOREIGN KEY (`daily_id`) REFERENCES `daily_sessions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=377 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_balance`
--

LOCK TABLES `daily_balance` WRITE;
/*!40000 ALTER TABLE `daily_balance` DISABLE KEYS */;
INSERT INTO `daily_balance` VALUES (372,1,0.00,30000.00,10000.00,0.00,-110000.00,'2026-03-17 21:31:14','2026-03-17 21:56:59'),(373,2,90000.00,0.00,0.00,0.00,100000.00,'2026-03-17 21:38:13','2026-03-17 22:05:14'),(374,4,484551.00,99118.66,2600.00,43700.00,326086.94,'2026-03-17 22:44:47','2026-03-17 22:47:53'),(375,3,90000.00,0.00,0.00,0.00,80000.00,'2026-03-17 22:45:12','2026-03-17 22:45:12'),(376,5,326127.00,0.00,0.00,0.00,326127.00,'2026-03-17 22:47:52','2026-03-17 22:47:52');
/*!40000 ALTER TABLE `daily_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_cash`
--

DROP TABLE IF EXISTS `daily_cash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_cash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `daily_id` int(10) unsigned NOT NULL,
  `cash_10000` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cash_200` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cash_100` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cash_50` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cash_20` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cash_10` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cash_5` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cash_1` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total_cash` decimal(14,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_daily_cash_daily_id` (`daily_id`),
  CONSTRAINT `fk_daily_cash_daily` FOREIGN KEY (`daily_id`) REFERENCES `daily_sessions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=377 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_cash`
--

LOCK TABLES `daily_cash` WRITE;
/*!40000 ALTER TABLE `daily_cash` DISABLE KEYS */;
INSERT INTO `daily_cash` VALUES (372,1,9.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,90000.00,'2026-03-17 21:31:14','2026-03-17 21:37:34'),(373,2,9.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,90000.00,'2026-03-17 21:38:13','2026-03-17 21:40:03'),(374,3,0.00,0.00,0.00,0.00,0.00,0.00,0.00,484551.00,484551.00,'2026-03-17 22:16:38','2026-03-17 22:23:18'),(375,4,31.00,0.00,97.00,92.00,54.00,28.00,1.00,462.00,326127.00,'2026-03-17 22:23:26','2026-03-17 22:27:35'),(376,5,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'2026-03-17 22:47:52','2026-03-17 22:47:52');
/*!40000 ALTER TABLE `daily_cash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_operation_summary`
--

DROP TABLE IF EXISTS `daily_operation_summary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_operation_summary` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `daily_id` int(10) unsigned NOT NULL,
  `input_transactions` decimal(14,2) NOT NULL DEFAULT '0.00',
  `input_transaction_outin` decimal(14,2) NOT NULL DEFAULT '0.00',
  `output_transactions` decimal(14,2) NOT NULL DEFAULT '0.00',
  `output_transaction_outin` decimal(14,2) NOT NULL DEFAULT '0.00',
  `input_transactions_account` decimal(14,2) NOT NULL DEFAULT '0.00',
  `output_transactions_account` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total_bills` decimal(14,2) NOT NULL DEFAULT '0.00',
  `vignette` decimal(14,2) NOT NULL DEFAULT '0.00',
  `phone_recharge` decimal(14,2) NOT NULL DEFAULT '0.00',
  `retailer` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cp_merchant` decimal(14,2) NOT NULL DEFAULT '0.00',
  `rest_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `total_result` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cmi_tamezmoute` decimal(14,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_daily_operation_summary_daily_id` (`daily_id`),
  CONSTRAINT `fk_daily_operation_summary_daily` FOREIGN KEY (`daily_id`) REFERENCES `daily_sessions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=377 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_operation_summary`
--

LOCK TABLES `daily_operation_summary` WRITE;
/*!40000 ALTER TABLE `daily_operation_summary` DISABLE KEYS */;
INSERT INTO `daily_operation_summary` VALUES (372,1,10000.00,10000.00,10000.00,10000.00,50000.00,10000.00,10000.00,10000.00,10000.00,10000.00,10000.00,90000.00,90000.00,0.00,'2026-03-17 21:31:14','2026-03-17 21:33:51'),(373,2,11000.00,1000.00,6000.00,6000.00,1000.00,6000.00,1000.00,1000.00,1000.00,1000.00,1000.00,90000.00,0.00,0.00,'2026-03-17 21:38:13','2026-03-17 22:10:14'),(374,3,10000.00,10000.00,50000.00,10000.00,10000.00,30000.00,10000.00,10000.00,10000.00,10000.00,10000.00,-10000.00,-10000.00,0.00,'2026-03-17 22:16:38','2026-03-17 22:43:17'),(375,4,12974.00,0.00,72526.30,0.00,43191.00,5478.00,3553.90,0.00,40.00,0.00,0.00,422605.60,-61945.40,0.00,'2026-03-17 22:23:26','2026-03-17 22:47:53'),(376,5,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,0.00,'2026-03-17 22:47:52','2026-03-17 22:47:52');
/*!40000 ALTER TABLE `daily_operation_summary` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `daily_sessions`
--

DROP TABLE IF EXISTS `daily_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `daily_sessions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `session_date` date NOT NULL,
  `status` enum('open','closed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `opened_by` int(10) unsigned DEFAULT NULL,
  `closed_by` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_daily_sessions_date` (`session_date`),
  KEY `fk_daily_sessions_opened_by` (`opened_by`),
  KEY `fk_daily_sessions_closed_by` (`closed_by`),
  CONSTRAINT `fk_daily_sessions_closed_by` FOREIGN KEY (`closed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_daily_sessions_opened_by` FOREIGN KEY (`opened_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `daily_sessions`
--

LOCK TABLES `daily_sessions` WRITE;
/*!40000 ALTER TABLE `daily_sessions` DISABLE KEYS */;
INSERT INTO `daily_sessions` VALUES (1,'2026-03-17','open',NULL,NULL,NULL,'2026-03-17 21:31:14','2026-03-17 21:31:14'),(2,'2026-03-18','open',NULL,NULL,NULL,'2026-03-17 21:38:12','2026-03-17 21:38:12'),(3,'2026-03-19','open',NULL,NULL,NULL,'2026-03-17 22:16:38','2026-03-17 22:16:38'),(4,'2026-03-20','open',NULL,NULL,NULL,'2026-03-17 22:23:26','2026-03-17 22:23:26'),(5,'2026-03-21','open',NULL,NULL,NULL,'2026-03-17 22:47:52','2026-03-17 22:47:52');
/*!40000 ALTER TABLE `daily_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `general_balance`
--

DROP TABLE IF EXISTS `general_balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `general_balance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `daily_id` int(10) unsigned NOT NULL,
  `opening_balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `agencies_balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cashplus_balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `bank_balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `cmi_tamezmoute` decimal(14,2) NOT NULL DEFAULT '0.00',
  `closing_balance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `balance_variance` decimal(14,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_general_balance_daily_id` (`daily_id`),
  CONSTRAINT `fk_general_balance_daily` FOREIGN KEY (`daily_id`) REFERENCES `daily_sessions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=377 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `general_balance`
--

LOCK TABLES `general_balance` WRITE;
/*!40000 ALTER TABLE `general_balance` DISABLE KEYS */;
INSERT INTO `general_balance` VALUES (372,1,0.00,0.00,0.00,0.00,0.00,110000.00,110000.00,'2026-03-17 21:31:14','2026-03-17 21:56:59'),(373,2,110000.00,0.00,0.00,0.00,0.00,90000.00,-20000.00,'2026-03-17 21:38:22','2026-03-17 22:05:14'),(374,3,90000.00,0.00,0.00,0.00,0.00,484551.00,394551.00,'2026-03-17 22:16:46','2026-03-17 22:23:18'),(375,4,484551.00,0.00,0.00,0.00,0.00,229608.34,-254942.66,'2026-03-17 22:37:32','2026-03-17 22:47:53'),(376,5,229608.34,0.00,0.00,0.00,0.00,0.00,-229608.34,'2026-03-17 22:47:52','2026-03-17 22:47:52');
/*!40000 ALTER TABLE `general_balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `daily_id` int(10) unsigned NOT NULL,
  `transaction_date` date NOT NULL,
  `client_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `paid_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `balance_due` decimal(14,2) NOT NULL DEFAULT '0.00',
  `today_in` tinyint(1) NOT NULL DEFAULT '0',
  `today_out` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_transactions_daily_id` (`daily_id`),
  KEY `idx_transactions_date` (`transaction_date`),
  KEY `idx_transactions_client_name` (`client_name`),
  KEY `idx_transactions_account_name` (`account_name`),
  CONSTRAINT `fk_transactions_daily` FOREIGN KEY (`daily_id`) REFERENCES `daily_sessions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3912 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (3905,1,'2026-03-17','abdo','AGENCE TAMEZOUT','floss',10000.00,0.00,10000.00,0,1,'2026-03-17 21:34:53'),(3906,1,'2026-03-17','abdo','AGENCE TAMEZOUT','flouss',0.00,30000.00,-30000.00,1,0,'2026-03-17 21:37:11'),(3910,4,'2026-03-20','abdo','AGENCE TAMEZOUT','flos',99118.66,0.00,99118.66,0,1,'2026-03-17 22:26:52'),(3911,4,'2026-03-20','abdo','AGENCE TAMEZOUT','flos',0.00,2600.00,-2600.00,1,0,'2026-03-17 22:27:04');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'cashplus_employer',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'developer','pbkdf2_sha256$390000$ee266140a1fc8ad4cedbaf1a8711856a$IjOGnPgGlk6MGZh41Xn49ANLLn+79nSB8Q4hAQBBST8=','admin','2026-03-16 21:42:33'),(2,'abdo','pbkdf2_sha256$390000$b042ef7fbcaa08156ec96e0fc80cd05c$XeLJEqzcu5bjNKIZcPMhZR5W+ea3MakUYAM2GDloLNA=','cashplus_employer','2026-03-16 21:43:41'),(3,'moh','pbkdf2_sha256$390000$4c4765de3976bc627ea12f5ae0508247$hxbltbH3ASYiJOarvvYn6R5YuYdc95VKQbzC2NwgJ8A=','tpe_employer','2026-03-16 21:43:52');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'konach_new'
--

--
-- Dumping routines for database 'konach_new'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-17 22:49:41
